package ado.pkg10.jogo.perguntas;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ADO10JOGOPERGUNTAS {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        int invalido = 0;

        int erros = 3;
        int tentativa;
        int attempt;

        do {
            System.out.println("Escolha o seu nivel de dificuldade para o jogo \n");

            System.out.println("---------------------------------------------------\n"
                    + "            Nivel 1\n"
                    + "     3 Salas - 21 Questões \n"
                    + "( Para jogar neste nivel Digite 1 ) \n"
                    + "---------------------------------------------------\n");
            System.out.println("---------------------------------------------------\n"
                    + "            Nivel 2\n"
                    + "     6 Salas - 42 Questões \n"
                    + "( Para jogar neste nivel Digite 2 ) \n"
                    + "---------------------------------------------------\n");
            System.out.println("---------------------------------------------------\n"
                    + "            Nivel 3\n"
                    + "     9 Salas - 63 Questões \n"
                    + "( Para jogar neste nivel Digite 3 ) \n"
                    + "---------------------------------------------------\n");

            System.out.print("Digite o nivel que deseja jogar ~> ");
            int nivel = entrada.nextInt();

            if (nivel > 0 && nivel < 4) {
                for (int i = nivel; i > 0; i = i - 1) {       // <<<< Repetição de 3, 6, ou 9, vezes de acordo com o nivel.

                    for (int j = 0; j < 3; j++) {      // <<<< Repetição de 3 vezes a sala, para cada nivel.

                        perguntas();

                    }
                    invalido = 0;
                }
            } else {
                System.out.println("Opção invalida");
                invalido = 1;
            }
        } while (invalido == 1);
        
        
        // Até aqui esta funcionando tudo 100%
        // Precisa pegar as questões e gerar a ordem aleatória
        
        

        /* String id1 = "", questions01 = "", a1 = "", b1 = "", c1 = "", d1 = "", e1 = "", respostaQ01 = "";
        
        questions01 = ""; // aqui vocÃª coloca a questÃ£o a ser resolvida
        
        a1 = "  ";  // aqui vocÃª coloca uma das alternativas
        b1 = "  ";  // aqui vocÃª coloca uma das alternativas
        c1 = "  ";  // aqui vocÃª coloca uma das alternativas
        d1 = "  ";  // aqui vocÃª coloca uma das alternativas
        e1 = "  ";  // aqui vocÃª coloca uma das alternativas
        
        respostaQ01 = "  "; // aqui vocÃª coloca a questÃ£o que serÃ¡ considerada a correta,
        //Obs. tem que esta exatamente como nas alternativas.
        
        Questões(id1, questions01, a1, b1, c1, d1, e1, respostaQ01);*/

        String id2 = "", questions02 = "", a2 = "", b2 = "", c2 = "", d2 = "", e2 = "", respostaQ02 = "";
        String id3 = "", questions03 = "", a3 = "", b3 = "", c3 = "", d3 = "", e3 = "", respostaQ03 = "";
        String id4 = "", questions04 = "", a4 = "", b4 = "", c4 = "", d4 = "", e4 = "", respostaQ04 = "";
        String id5 = "", questions05 = "", a5 = "", b5 = "", c5 = "", d5 = "", e5 = "", respostaQ05 = "";
        String id6 = "", questions06 = "", a6 = "", b6 = "", c6 = "", d6 = "", e6 = "", respostaQ06 = "";
        String id7 = "", questions07 = "", a7 = "", b7 = "", c7 = "", d7 = "", e7 = "", respostaQ07 = "";
        String id8 = "", questions08 = "", a8 = "", b8 = "", c8 = "", d8 = "", e8 = "", respostaQ08 = "";
        String id9 = "", questions09 = "", a9 = "", b9 = "", c9 = "", d = "", e9 = "", respostaQ09 = "";
        String id10 = "", questions10 = "", a10 = "", b10 = "", c10 = "", d11 = "", e10 = "", respostaQ10 = "";
        String id11 = "", questions11 = "", a11 = "", b11 = "", c11 = "", d12 = "", e11 = "", respostaQ11 = "";
        String id12 = "", questions12 = "", a12 = "", b12 = "", c12 = "", d13 = "", e12 = "", respostaQ12 = "";
        String id13 = "", questions13 = "", a13 = "", b13 = "", c13 = "", d14 = "", e13 = "", respostaQ13 = "";
        String id14 = "", questions14 = "", a14 = "", b14 = "", c14 = "", d15 = "", e14 = "", respostaQ14 = "";
        String id15 = "", questions15 = "", a15 = "", b15 = "", c15 = "", d16 = "", e15 = "", respostaQ15 = "";
        String id16 = "", questions16 = "", a16 = "", b16 = "", c16 = "", d17 = "", e16 = "", respostaQ16 = "";
        String id17 = "", questions17 = "", a17 = "", b17 = "", c17 = "", d18 = "", e17 = "", respostaQ17 = "";
        String id18 = "", questions18 = "", a18 = "", b18 = "", c18 = "", d19 = "", e18 = "", respostaQ18 = "";
        String id19 = "", questions19 = "", a19 = "", b19 = "", c19 = "", d20 = "", e19 = "", respostaQ19 = "";
        String id20 = "", questions20 = "", a20 = "", b20 = "", c20 = "", d21 = "", e20 = "", respostaQ20 = "";
        String id21 = "", questions21 = "", a21 = "", b21 = "", c21 = "", d22 = "", e21 = "", respostaQ21 = "";
        String id22 = "", questions22 = "", a22 = "", b22 = "", c22 = "", d23 = "", e22 = "", respostaQ22 = "";
        String id23 = "", questions23 = "", a23 = "", b23 = "", c23 = "", d24 = "", e23 = "", respostaQ23 = "";
        String id24 = "", questions24 = "", a24 = "", b24 = "", c24 = "", d25 = "", e24 = "", respostaQ24 = "";
        String id25 = "", questions25 = "", a25 = "", b25 = "", c25 = "", d26 = "", e25 = "", respostaQ25 = "";
        String id26 = "", questions26 = "", a26 = "", b26 = "", c26 = "", d27 = "", e26 = "", respostaQ26 = "";
        String id27 = "", questions27 = "", a27 = "", b27 = "", c27 = "", d28 = "", e27 = "", respostaQ27 = "";
        String id28 = "", questions28 = "", a28 = "", b28 = "", c28 = "", d29 = "", e28 = "", respostaQ28 = "";
        String id29 = "", questions29 = "", a29 = "", b29 = "", c29 = "", d30 = "", e29 = "", respostaQ29 = "";
        String id30 = "", questions30 = "", a30 = "", b30 = "", c30 = "", d31 = "", e30 = "", respostaQ30 = "";
        String id31 = "", questions31 = "", a31 = "", b31 = "", c31 = "", d32 = "", e31 = "", respostaQ31 = "";
        String id32 = "", questions32 = "", a32 = "", b32 = "", c32 = "", d33 = "", e32 = "", respostaQ32 = "";
        String id33 = "", questions33 = "", a33 = "", b33 = "", c33 = "", d34 = "", e33 = "", respostaQ33 = "";
        String id34 = "", questions34 = "", a34 = "", b34 = "", c34 = "", d35 = "", e34 = "", respostaQ34 = "";
        String id35 = "", questions35 = "", a35 = "", b35 = "", c35 = "", d36 = "", e35 = "", respostaQ35 = "";
        String id36 = "", questions36 = "", a36 = "", b36 = "", c36 = "", d37 = "", e36 = "", respostaQ36 = "";
        String id37 = "", questions37 = "", a37 = "", b37 = "", c37 = "", d38 = "", e37 = "", respostaQ37 = "";
        String id38 = "", questions38 = "", a38 = "", b38 = "", c38 = "", d39 = "", e38 = "", respostaQ38 = "";
        String id39 = "", questions39 = "", a39 = "", b39 = "", c39 = "", d40 = "", e39 = "", respostaQ39 = "";
        String id40 = "", questions40 = "", a40 = "", b40 = "", c40 = "", d41 = "", e40 = "", respostaQ40 = "";
        String id41 = "", questions41 = "", a41 = "", b41 = "", c41 = "", d42 = "", e41 = "", respostaQ41 = "";
        String id42 = "", questions42 = "", a42 = "", b42 = "", c42 = "", d43 = "", e42 = "", respostaQ42 = "";
        String id43 = "", questions43 = "", a43 = "", b43 = "", c43 = "", d44 = "", e43 = "", respostaQ43 = "";
        String id44 = "", questions44 = "", a44 = "", b44 = "", c44 = "", d45 = "", e44 = "", respostaQ44 = "";
        String id45 = "", questions45 = "", a45 = "", b45 = "", c45 = "", d46 = "", e45 = "", respostaQ45 = "";
        String id46 = "", questions46 = "", a46 = "", b46 = "", c46 = "", d47 = "", e46 = "", respostaQ46 = "";
        String id47 = "", questions47 = "", a47 = "", b47 = "", c47 = "", d48 = "", e47 = "", respostaQ47 = "";
        String id48 = "", questions48 = "", a48 = "", b48 = "", c48 = "", d49 = "", e48 = "", respostaQ48 = "";
        String id49 = "", questions49 = "", a49 = "", b49 = "", c49 = "", d50 = "", e49 = "", respostaQ49 = "";
        String id50 = "", questions50 = "", a50 = "", b50 = "", c50 = "", d51 = "", e50 = "", respostaQ50 = "";
        String id51 = "", questions51 = "", a51 = "", b51 = "", c51 = "", d52 = "", e51 = "", respostaQ51 = "";
        String id52 = "", questions52 = "", a52 = "", b52 = "", c52 = "", d53 = "", e52 = "", respostaQ52 = "";
        String id53 = "", questions53 = "", a53 = "", b53 = "", c53 = "", d54 = "", e53 = "", respostaQ53 = "";
        String id54 = "", questions54 = "", a54 = "", b54 = "", c54 = "", d55 = "", e54 = "", respostaQ54 = "";
        String id55 = "", questions55 = "", a55 = "", b55 = "", c55 = "", d56 = "", e55 = "", respostaQ55 = "";
        String id56 = "", questions56 = "", a56 = "", b56 = "", c56 = "", d57 = "", e56 = "", respostaQ56 = "";
        String id57 = "", questions57 = "", a57 = "", b57 = "", c57 = "", d58 = "", e57 = "", respostaQ57 = "";
        String id58 = "", questions58 = "", a58 = "", b58 = "", c58 = "", d59 = "", e58 = "", respostaQ58 = "";
        String id59 = "", questions59 = "", a59 = "", b59 = "", c59 = "", d60 = "", e59 = "", respostaQ59 = "";
        String id60 = "", questions60 = "", a60 = "", b60 = "", c60 = "", d61 = "", e60 = "", respostaQ60 = "";
        String id61 = "", questions61 = "", a61 = "", b61 = "", c61 = "", d62 = "", e61 = "", respostaQ61 = "";
        String id62 = "", questions62 = "", a62 = "", b62 = "", c62 = "", d63 = "", e62 = "", respostaQ62 = "";

        /*        Questões(id1 = "", questions01 = "", a1 = "", b1 = "", c1 = "", d1 = "", e1 = "", respostaQ01 = "");
        Questões(id2 = "", questions02 = "", a2 = "", b2 = "", c2 = "", d2 = "", e2 = "", respostaQ02 = "");
        Questões(id3 = "", questions03 = "", a3 = "", b3 = "", c3 = "", d3 = "", e3 = "", respostaQ03 = "");
        Questões(id4 = "", questions04 = "", a4 = "", b4 = "", c4 = "", d4 = "", e4 = "", respostaQ04 = "");
        Questões(id5 = "", questions05 = "", a5 = "", b5 = "", c5 = "", d5 = "", e5 = "", respostaQ05 = "");
        Questões(id6 = "", questions06 = "", a6 = "", b6 = "", c6 = "", d6 = "", e6 = "", respostaQ06 = "");
        Questões(id7 = "", questions07 = "", a7 = "", b7 = "", c7 = "", d7 = "", e7 = "", respostaQ07 = "");
        Questões(id8 = "", questions08 = "", a8 = "", b8 = "", c8 = "", d8 = "", e8 = "", respostaQ08 = "");
        Questões(id9 = "", questions09 = "", a9 = "", b9 = "", c9 = "", d = "", e9 = "", respostaQ09 = "");
        Questões(id10 = "", questions10 = "", a10 = "", b10 = "", c10 = "", d11 = "", e10 = "", respostaQ10 = "");
        Questões(id11 = "", questions11 = "", a11 = "", b11 = "", c11 = "", d12 = "", e11 = "", respostaQ11 = "");
        Questões(id12 = "", questions12 = "", a12 = "", b12 = "", c12 = "", d13 = "", e12 = "", respostaQ12 = "");
        Questões(id13 = "", questions13 = "", a13 = "", b13 = "", c13 = "", d14 = "", e13 = "", respostaQ13 = "");
        Questões(id14 = "", questions14 = "", a14 = "", b14 = "", c14 = "", d15 = "", e14 = "", respostaQ14 = "");
        Questões(id15 = "", questions15 = "", a15 = "", b15 = "", c15 = "", d16 = "", e15 = "", respostaQ15 = "");
        Questões(id16 = "", questions16 = "", a16 = "", b16 = "", c16 = "", d17 = "", e16 = "", respostaQ16 = "");
        Questões(id17 = "", questions17 = "", a17 = "", b17 = "", c17 = "", d18 = "", e17 = "", respostaQ17 = "");
        Questões(id18 = "", questions18 = "", a18 = "", b18 = "", c18 = "", d19 = "", e18 = "", respostaQ18 = "");
        Questões(id19 = "", questions19 = "", a19 = "", b19 = "", c19 = "", d20 = "", e19 = "", respostaQ19 = "");
        Questões(id20 = "", questions20 = "", a20 = "", b20 = "", c20 = "", d21 = "", e20 = "", respostaQ20 = "");
        Questões(id21 = "", questions21 = "", a21 = "", b21 = "", c21 = "", d22 = "", e21 = "", respostaQ21 = "");
        Questões(id22 = "", questions22 = "", a22 = "", b22 = "", c22 = "", d23 = "", e22 = "", respostaQ22 = "");
        Questões(id23 = "", questions23 = "", a23 = "", b23 = "", c23 = "", d24 = "", e23 = "", respostaQ23 = "");
        Questões(id24 = "", questions24 = "", a24 = "", b24 = "", c24 = "", d25 = "", e24 = "", respostaQ24 = "");
        Questões(id25 = "", questions25 = "", a25 = "", b25 = "", c25 = "", d26 = "", e25 = "", respostaQ25 = "");
        Questões(id26 = "", questions26 = "", a26 = "", b26 = "", c26 = "", d27 = "", e26 = "", respostaQ26 = "");
        Questões(id27 = "", questions27 = "", a27 = "", b27 = "", c27 = "", d28 = "", e27 = "", respostaQ27 = "");
        Questões(id28 = "", questions28 = "", a28 = "", b28 = "", c28 = "", d29 = "", e28 = "", respostaQ28 = "");
        Questões(id29 = "", questions29 = "", a29 = "", b29 = "", c29 = "", d30 = "", e29 = "", respostaQ29 = "");
        Questões(id30 = "", questions30 = "", a30 = "", b30 = "", c30 = "", d31 = "", e30 = "", respostaQ30 = "");
        Questões(id31 = "", questions31 = "", a31 = "", b31 = "", c31 = "", d32 = "", e31 = "", respostaQ31 = "");
        Questões(id32 = "", questions32 = "", a32 = "", b32 = "", c32 = "", d33 = "", e32 = "", respostaQ32 = "");
        Questões(id33 = "", questions33 = "", a33 = "", b33 = "", c33 = "", d34 = "", e33 = "", respostaQ33 = "");
        Questões(id34 = "", questions34 = "", a34 = "", b34 = "", c34 = "", d35 = "", e34 = "", respostaQ34 = "");
        Questões(id35 = "", questions35 = "", a35 = "", b35 = "", c35 = "", d36 = "", e35 = "", respostaQ35 = "");
        Questões(id36 = "", questions36 = "", a36 = "", b36 = "", c36 = "", d37 = "", e36 = "", respostaQ36 = "");
        Questões(id37 = "", questions37 = "", a37 = "", b37 = "", c37 = "", d38 = "", e37 = "", respostaQ37 = "");
        Questões(id38 = "", questions38 = "", a38 = "", b38 = "", c38 = "", d39 = "", e38 = "", respostaQ38 = "");
        Questões(id39 = "", questions39 = "", a39 = "", b39 = "", c39 = "", d40 = "", e39 = "", respostaQ39 = "");
        Questões(id40 = "", questions40 = "", a40 = "", b40 = "", c40 = "", d41 = "", e40 = "", respostaQ40 = "");
        Questões(id41 = "", questions41 = "", a41 = "", b41 = "", c41 = "", d42 = "", e41 = "", respostaQ41 = "");
        Questões(id42 = "", questions42 = "", a42 = "", b42 = "", c42 = "", d43 = "", e42 = "", respostaQ42 = "");
        Questões(id43 = "", questions43 = "", a43 = "", b43 = "", c43 = "", d44 = "", e43 = "", respostaQ43 = "");
        Questões(id44 = "", questions44 = "", a44 = "", b44 = "", c44 = "", d45 = "", e44 = "", respostaQ44 = "");
        Questões(id45 = "", questions45 = "", a45 = "", b45 = "", c45 = "", d46 = "", e45 = "", respostaQ45 = "");
        Questões(id46 = "", questions46 = "", a46 = "", b46 = "", c46 = "", d47 = "", e46 = "", respostaQ46 = "");
        Questões(id47 = "", questions47 = "", a47 = "", b47 = "", c47 = "", d48 = "", e47 = "", respostaQ47 = "");
        Questões(id48 = "", questions48 = "", a48 = "", b48 = "", c48 = "", d49 = "", e48 = "", respostaQ48 = "");
        Questões(id49 = "", questions49 = "", a49 = "", b49 = "", c49 = "", d50 = "", e49 = "", respostaQ49 = "");
        Questões(id50 = "", questions50 = "", a50 = "", b50 = "", c50 = "", d51 = "", e50 = "", respostaQ50 = "");
        Questões(id51 = "", questions51 = "", a51 = "", b51 = "", c51 = "", d52 = "", e51 = "", respostaQ51 = "");
        Questões(id52 = "", questions52 = "", a52 = "", b52 = "", c52 = "", d53 = "", e52 = "", respostaQ52 = "");
        Questões(id53 = "", questions53 = "", a53 = "", b53 = "", c53 = "", d54 = "", e53 = "", respostaQ53 = "");
        Questões(id54 = "", questions54 = "", a54 = "", b54 = "", c54 = "", d55 = "", e54 = "", respostaQ54 = "");
        Questões(id55 = "", questions55 = "", a55 = "", b55 = "", c55 = "", d56 = "", e55 = "", respostaQ55 = "");
        Questões(id56 = "", questions56 = "", a56 = "", b56 = "", c56 = "", d57 = "", e56 = "", respostaQ56 = "");
        Questões(id57 = "", questions57 = "", a57 = "", b57 = "", c57 = "", d58 = "", e57 = "", respostaQ57 = "");
        Questões(id58 = "", questions58 = "", a58 = "", b58 = "", c58 = "", d59 = "", e58 = "", respostaQ58 = "");
        Questões(id59 = "", questions59 = "", a59 = "", b59 = "", c59 = "", d60 = "", e59 = "", respostaQ59 = "");
        Questões(id60 = "", questions60 = "", a60 = "", b60 = "", c60 = "", d61 = "", e60 = "", respostaQ60 = "");
        Questões(id61 = "", questions61 = "", a61 = "", b61 = "", c61 = "", d62 = "", e61 = "", respostaQ61 = "");
        Questões(id62 = "", questions62 = "", a62 = "", b62 = "", c62 = "", d63 = "", e62 = "", respostaQ62 = "");*/

    }

    private static void perguntas() {

    }

    private static void Questões(String id, String questions, String a, String b, String c, String d, String e, String r) {
        Scanner input = new Scanner(System.in);
        int repeat = 0;
        int extra = 3;

        do {

            System.out.println("================================================");
            System.out.println("");
            System.out.println(questions);
            System.out.println("");
            System.out.println("================================================");

            ArrayList<String> mistureba = new ArrayList<>();

            mistureba.add(a);
            mistureba.add(b);
            mistureba.add(c);
            mistureba.add(d);
            mistureba.add(e);

            Collections.shuffle(mistureba);

            System.out.println("( A )" + mistureba.get(0));
            System.out.println("( B )" + mistureba.get(1));
            System.out.println("( C )" + mistureba.get(2));
            System.out.println("( D )" + mistureba.get(3));
            System.out.println("( E )" + mistureba.get(4));

            String nv_a = mistureba.get(0);
            String nv_b = mistureba.get(1);
            String nv_c = mistureba.get(2);
            String nv_d = mistureba.get(3);
            String nv_e = mistureba.get(4);

            System.out.println("Escolha uma das alternativas que apreseta a resposta correta");

            String cResp = r;

            String alternativa = input.next();

            switch (alternativa) {
                case "a":

                    if (nv_a.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " vidas ");
                    }
                    break;

                case "A":
                    if (nv_a.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " vidas ");
                    }

                    break;

                case "b":
                    if (nv_b.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;

                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " vidas ");
                    }
                    break;

                case "B":
                    if (nv_b.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " vidas ");
                    }
                    break;

                case "c":
                    if (nv_c.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " vidas ");
                    }
                    break;

                case "C":
                    if (nv_c.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " tentativas ");
                    }
                    break;

                case "d":
                    if (nv_d.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " tentativas ");
                    }
                    break;

                case "D":
                    if (nv_d.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " tentativas ");
                    }
                    break;

                case "e":
                    if (nv_e.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " tentativas ");
                    }
                    break;

                case "E":
                    if (nv_e.equals(cResp)) {
                        System.out.println("ALTERNATIVA CORRETA !!");
                        System.out.println(" acertou na tentativa " + extra);
                        repeat = 50;
                    } else {
                        System.out.println("ALTERNATIVA INCORRETA");
                        extra -= 1;
                        System.out.println(" Restam " + extra + " tentativas ");
                    }
                    break;

                default:
                    System.out.println("TENTE NOVAMENTE");
            }

            if (extra == 0) {
                System.out.println("Fim do jogo");
                repeat = 50;
            }
            System.out.println(" ==============================================");
        } while (repeat != 50);

    }

}

/*private static void sala() {
    int i = 0;
    
    do {
    
    int tentativa = bancodeperguntas();
    
    System.out.println(tentativa);
    i++;
    
    } while (i < 7);
    }
    
    private static int Questões(String id, String p, String a, String b, String c, String d, String e, String r) {
    
    Scanner entrada = new Scanner(System.in);
    
    String[][] questio = new String[4][];
    
    int numeroDeTentativas = 0;
    
    questio[0] = new String[0]; // id Validador de repetição de questão
    questio[1] = new String[1]; // Pergunta
    questio[2] = new String[5]; // Opções
    questio[3] = new String[1]; // resposta correta
    
    String identificador = id;
    String pergunta = p;
    String qst1 = a;
    String qst2 = b;
    String qst3 = c;
    String qst4 = d;
    String qst5 = e;
    String resposta = r;
    
    String questão[][] = {{identificador}, {pergunta}, {qst1, qst2, qst3, qst4, qst5}, {resposta}};
    
    System.out.println(p);
    System.out.println(" Alternativa ( A ) " + a);
    System.out.println(" Alternativa ( B ) " + b);
    System.out.println(" Alternativa ( C ) " + c);
    System.out.println(" Alternativa ( D ) " + d);
    System.out.println(" Alternativa ( E ) " + e);
    
    String selecao = entrada.next();
    
    if (selecao.equals(r)) {
    System.out.println("Resposta correta");
    numeroDeTentativas = numeroDeTentativas + 1;
    } else {
    System.out.println("Resposta incorreta");
    }
    
    return numeroDeTentativas;
    }
    
    private static int bancodeperguntas() {
    
    String id1 = "1";
    String questions01 = "Normalmente, quantos litros de sangue uma pessoa tem? Em média, quantos são retirados numa doação de sangue?";
    String a1 = "Tem entre 2 a 4 litros. São retirados 450 mililitros";
    String b1 = "Tem entre 4 a 6 litros. São retirados 450 mililitros";
    String c1 = "Tem 10 litros. São retirados 2 litros";
    String d1 = "Tem 7 litros. São retirados 1,5 litros";
    String e1 = "Tem 0,5 litros. São retirados 0,5 litros";
    String respostaQ01 = "b";
    
    int tentativa = Questões(id1, questions01, a1, b1, c1, d1, e1, respostaQ01);
    
    String id2 = "2";
    String questions02 = "questão dois 1 + 1";
    String a2 = "2";
    String b2 = "Tem entre 4 a 6 litros. São retirados 450 mililitros";
    String c2 = "Tem 10 litros. São retirados 2 litros";
    String d2 = "Tem 7 litros. São retirados 1,5 litros";
    String e2 = "Tem 0,5 litros. São retirados 0,5 litros";
    String respostaQ02 = "2";
    
    Questões(id2, questions02, a2, b2, c2, d2, e2, respostaQ02);
    
    return tentativa;
    }*/
 /*

Em resulmo.

montar um menu de seleção de niveis
    
    O menu deverá setá uma variavel de 1 a 3, que será a escolha dos niveis <<<<<< EM PROCESSO DE CRIAÇÃO.
        
            
        1 - Função de retorno das perguntas, assim como suas respectivas respostas,
        já no formato de aleatóriedade de questoes, e com as perguntas também aleatorias,
        deverá conter dentro de cada qustão, um retorno, adicional, que enviará a classe main
        que a questão X já foi escolhida, então ele deverá coletar outra. "por exemplo atraves
        de um Id, para cada questão", ele deverá armazenar em um array "questõesJaSeleciondas", todas as questoes já pré
        selecionadas.
        
        Exemplo de Array de questão
        (id - Questão - alternativa 1 - alternativa 2 - alternativa 3 - alternativa 4 - alternativa 5 - Boolean)

        Então quando ele verificará se o id x, já foi selecionado alguma vez, atravez de um laço for, 
        que passará por todas as questores do Array "questõesJaSeleciondas" caso a questão aleatória já tenha sido 
        escolhida, ele irá retornar atrávez de um laço de repetição DO While, invocando novamente a função "questão", 
        e verificando se a mesma já foi selecionada alguma vez.
        
        2 - dentro da função nivel, deve receber apenas o retorno boolean, (se verdadeiro,
        seta uma variavel dentro da função nivel, que armazenará se a resposta foi correta), para então
        ter o controle de perguntas corretas da sala, atravez de um "if (tentativa == 3){Fim do Jogo}"

        3 - Um laço de repetição deve ser criado "for (int i = 7; i > 0; i = i - 1 )" <= para que repita tudo durante
        durante as 7 vezes que deve responder as questões durante o Game.

        4 - Após as 7 perguntas, se ele teve um resultado satisfatório, o jogo deve retornar a classe main, dentro de um
        "For já setado para repetir 3 vezes, a função sala." 

        5 - o passo 4 deve estar dentro de outro laço de repetição "for" onde o valor setado da variavel (i) será igual ao
        nivel escolhido no inicio do jogo, desta forma, ele repetirar as quantidades de vezes escolhidas, de acordo com o
        ninvel escolhido. (Ex. nivel 3, repete 3 vezes, o For que representará as salas 3 salas de cada nivel, ou seja,
        no nivel 3 o jogador passará por 9 salas, no nivel 2, por 6 salas, e no nivel 1, por 3 salas, e em cada sala, o laço
        laço de repetição apresentado na etapa 3, garantirá a execução das 7 questões, aleatórias, não repetidas, com seu
        validador de tentativas.)
        



Caros,c

     Usando o que aprendemos na aula, fazer um exercício que gerem perguntas a um jogador e 5 opções de multipla escolha. O programa deve:

Permitir a escolha de nível de dificuldade (1,2,3)
No jogo, para cada nível, o usuário deverá entrar em 3 salas, sequenciamente e, se responder 3 de 5 perguntas corretamente, ele passará para a próxima sala.
Chegando na terceira sala, para aquele nível,  se responder 3 de 5 perguntas corretamente, ele vencerá o jogo.
Se errar 3 de cinco perguntas em qualquer sala, ele perderá o jogo.
Gerar perguntas em ordem aleatória para cada sala e para cada nível.
Gerar as opções de forma aleatoria;
Garantir que a opção correta seja encontrada.
O jogo deve ter 7 perguntas por sala.
Usar vetores, matrizes e funções como foi ensinado nas aulas de 01/06 e 08/06.

att,

Prof. Leonildo*/
