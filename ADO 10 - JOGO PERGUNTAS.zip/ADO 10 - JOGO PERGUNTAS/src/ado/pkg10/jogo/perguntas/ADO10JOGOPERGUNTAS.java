package ado.pkg10.jogo.perguntas;

import java.util.Scanner;

public class ADO10JOGOPERGUNTAS {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        
        

    }

}



