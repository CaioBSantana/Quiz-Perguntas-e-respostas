package ado.pkg10.jogo.perguntas;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

public class ADO10JOGOPERGUNTAS1 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        int invalido = 0;

        int erros = 3;
        int tentativa;
        int attempt;

     
        ArrayList<Integer> perguntasJaEscolhidas = new ArrayList<>();

        Random random = new Random();
        int maximo = 1;
        int minimo = 14;
        boolean repetirOperacao = false;

        do { // Repete a operação de geração de numeros aleatórios caso já tenha sido usado.

            int rd = random.nextInt((maximo - minimo) + 1) + minimo; // gerador de pergunta aleatoria apartir do valor do random.

            perguntasJaEscolhidas.add(rd); // adiciona no array a pergunta já utilizada.

            for (int i = minimo; i < maximo; i++) { // percorre todas as perguntas

                if (perguntasJaEscolhidas.get(i) == rd) { // verifica se já foi usada a pergunta
                    repetirOperacao = true;
                    System.out.println(" numero repetido " + rd);
                    System.out.println("lista " + perguntasJaEscolhidas.get(i));
                    System.out.println("");
                } else {
                    // vai chamar e reconstruir o array já com as alternativas embaralhadas
                    System.out.println(" numero não repetido " + rd);
                    System.out.println("lista " + perguntasJaEscolhidas.get(i));

                }
            }

        } while (repetirOperacao == true);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        /*do {
        System.out.println("Escolha o seu nivel de dificuldade para o jogo \n");
        
        System.out.println("---------------------------------------------------\n"
        + "            Nivel 1\n"
        + "     3 Salas - 21 Questões \n"
        + "( Para jogar neste nivel Digite 1 ) \n"
        + "---------------------------------------------------\n");
        System.out.println("---------------------------------------------------\n"
        + "            Nivel 2\n"
        + "     6 Salas - 42 Questões \n"
        + "( Para jogar neste nivel Digite 2 ) \n"
        + "---------------------------------------------------\n");
        System.out.println("---------------------------------------------------\n"
        + "            Nivel 3\n"
        + "     9 Salas - 63 Questões \n"
        + "( Para jogar neste nivel Digite 3 ) \n"
        + "---------------------------------------------------\n");
        
        
        System.out.print("Digite o nivel que deseja jogar ~> ");
        int nivel = entrada.nextInt();
        
        if (nivel > 0 && nivel < 4) {
        for (int i = nivel; i > 0; i = i - 1) {       // <<<< Repetição de 3, 6, ou 9, vezes de acordo com o nivel.
        
        for (int j = 0; j < 3; j++) {      // <<<< Repetição de 3 vezes a sala, para cada nivel.
        
        System.out.println("Bom dia");
        
        }
        invalido = 0;
        }
        } else {
        System.out.println("Opção invalida");
        invalido = 1;
        }
        } while (invalido == 1);*/
    }

    static String perguntas() {

        // 0 - Pergunta 
        // 1 - Alternativa A 
        // 2 - Alternariva B 
        // 3 - Alternariva B 
        // 4 - Alternariva C 
        // 5 - Alternariva D 
        // 6 - Alternariva D 
        // 7 - Resposta correta
        String ID0[][] = {{"Normalmente, quantos litros de sangue uma pessoa tem? Em média, quantos são retirados numa doação de sangue?", "Tem entre 2 a 4 litros. São retirados 450 mililitros"}, {"Tem entre 4 a 6 litros. São retirados 450 mililitros", "Tem 10 litros. São retirados 2 litros", "Tem 7 litros. São retirados 1,5 litros", "Tem 0,5 litros. São retirados 0,5 litros", "Tem 0,5 litros. São retirados 0,5 litros"}};
        String ID1[] = {"De quem é a famosa frase “Penso, logo existo”?", "Platão", " Galileu Galilei", "Descartes", " Sócrates", " Francis Bacon", "Descartes"};
        String ID2[] = {"De onde é a invenção do chuveiro elétrico?", "França", "Inglaterra", "Brasil", "Austrália", "Itália", "Brasil"};
        String ID3[] = {"Quais o menor e o maior país do mundo?", " Vaticano e Rússia", "Nauru e China", "Mônaco e Canadá", "Malta e Estados Unidos", "São Marino e Índia", "Vaticano e Rússia"};
        String ID4[] = {"Qual o nome do presidente do Brasil que ficou conhecido como Jango?", " Jânio Quadros", "Jacinto Anjos", "Getúlio Vargas", " João Figueiredo", " João Goulart", " João Goulart"};
        String ID5[] = {"Qual o grupo em que todas as palavras foram escritas corretamente?", "Asterístico, beneficiente, meteorologia, entertido", " Asterisco, beneficente, meteorologia, entretido", "Asterisco, beneficente, metereologia, entretido", "Asterístico, beneficiente, metereologia, entretido", "Asterisco, beneficiente, metereologia, entretido", "Asterisco, beneficente, meteorologia, entretido"};
        String ID6[] = {"Qual o livro mais vendido no mundo a seguir à Bíblia?", "O Senhor dos Anéis", "Dom Quixote", "O Pequeno Príncipe", " Ela, a Feiticeira", "Um Conto de Duas Cidades", " Dom Quixote"};
        String ID7[] = {"Quantas casas decimais tem o número pi?", "Duas", "Centenas", "Infinitas", "Vinte", "Milhares", "Infinitas"};
        String ID8[] = {"Atualmente, quantos elementos químicos a tabela periódica possui?", "113", "109", "108", "118", "92", "118"};
        String ID9[] = {"Quais os países que têm a maior e a menor expectativa de vida do mundo?", " Japão e Serra Leoa", "Austrália e Afeganistão", "Itália e Chade", "Brasil e Congo", "Estados Unidos e Angola", " Japão e Serra Leoa"};
        String ID10[] = {"O que a palavra legend significa em português?", "Legenda", "Conto", "História", "Lenda", "Legendário", "Lenda"};
        String ID11[] = {"Qual o número mínimo de jogadores numa partida de futebol?", "8", "10", "9", "5", "7", "7"};
        String ID12[] = {"Quais os principais autores do Barroco no Brasil?", "Gregório de Matos, Bento Teixeira e Manuel Botelho de Oliveira", "Miguel de Cervantes, Gregório de Matos e Danthe Alighieri", "Padre Antônio Vieira, Padre Manuel de Melo e Gregório de Matos", "Castro Alves, Bento Teixeira e Manuel Botelho de Oliveira", " Álvares de Azevedo, Gregório de Matos e Bento Teixeira", "Gregório de Matos, Bento Teixeira e Manuel Botelho de Oliveira"};
        String ID13[] = {"Quais as duas datas que são comemoradas em novembro?", " Independência do Brasil e Dia da Bandeira", "Proclamação da República e Dia Nacional da Consciência Negra", "Dia do Médico e Dia de São Lucas", "Dia de Finados e Dia Nacional do Livro", "Black Friday e Dia da Árvore", "Proclamação da República e Dia Nacional da Consciência Negra"};
        String ID14[] = {"Quem pintou 'Guernica?'", "Paul Cézanne", "Pablo Picasso", "Diego Rivera", "Tarsila do Amaral", "Salvador Dalí", "Pablo Picasso"};

        String a1 = "casa";

        ArrayList<String> mistureba = new ArrayList<>();
        ArrayList<Integer> perguntasJaEscolhidas = new ArrayList<Integer>();

        Random random = new Random();
        int maximo = 0;
        int minimo = 14;
        boolean repetirOperacao = false;

        do { // Repete a operação de geração de numeros aleatórios caso já tenha sido usado.

            int rd = random.nextInt((maximo - minimo) + 1) + minimo; // gerador de pergunta aleatoria apartir do valor do random.

            perguntasJaEscolhidas.add(rd); // adiciona no array a pergunta já utilizada.

            for (int i = minimo; i < maximo; i++) { // percorre todas as perguntas

                if (perguntasJaEscolhidas.get(i) == rd) { // verifica se já foi usada a pergunta
                    repetirOperacao = true;
                    System.out.println(" numero repetido " + rd);
                    System.out.println("lista " + perguntasJaEscolhidas.get(i));
                    System.out.println("");
                } else {
                    // vai chamar e reconstruir o array já com as alternativas embaralhadas
                    System.out.println(" numero não repetido " + rd);
                    System.out.println("lista " + perguntasJaEscolhidas.get(i));

                }
            }

        } while (repetirOperacao == true);

        mistureba.add(ID0[1][2]);

        Collections.shuffle(mistureba);

        String nv_a = mistureba.get(0);
        String nv_b = mistureba.get(1);
        String nv_c = mistureba.get(2);
        String nv_d = mistureba.get(3);
        String nv_e = mistureba.get(4);

        return null;

    }
}
